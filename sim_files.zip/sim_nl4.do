* sim_nl4.do


clear all
set more off
version 15

local K     = 4
local N     = 2000
local REPS  = 1000
set seed 20260104

local outfile "E:/ArielStuff/esize_sims/sim_nl_results_k4_n2000.dta"

local gammalist "0 0.25 0.5 1"
local balancelist "equal unequal"

local mulist "0 1.5 3 4.5"
forvalues j = 1/`K' {
	local mu`j' : word `j' of `mulist'
}

capture postclose simres
postfile simres double(k n gamma balance wtarm covnum f mean_abs_d max_abs_d ///
	mean_abs_bias max_abs_bias rep) ///
	using "`outfile'", replace

local repcount  = 0
local failcount = 0

di as txt _n "k=4 n=2000: `=`REPS'*8' replicates total (`REPS' per cell x 8 cells)"

foreach bal of local balancelist {

	forvalues j = 2/`K' {
		if "`bal'" == "equal" {
			local alpha`j' = 0
		}
		else {
			local alpha`j' = -0.4 - 0.15*(`j'-2)
		}
	}

	foreach gam of local gammalist {

		di as txt _n "bal=`bal' gamma=`gam': `REPS' reps"
		_dots 0 0

		forvalues rep = 1/`REPS' {

			local ++repcount
			local failcount_before = `failcount'

			quietly {

				clear
				set obs `N'

				gen double x1 = rnormal(0,1)
				gen double x2 = exp(rnormal(0,0.5))
				gen byte   x3 = rbinomial(1,0.4)

				gen double e1 = 1
				local evars "e1"
				local etavars ""
				forvalues j = 2/`K' {
					gen double eta`j' = `alpha`j'' + `gam'*(0.3*`j'*x1 + 0.2*x2 + 0.4*x3 + 0.25*x1*x3)
					gen double e`j'   = exp(eta`j')
					local evars "`evars' e`j'"
					local etavars "`etavars' eta`j'"
				}
				egen double esum = rowtotal(`evars')

				gen double cp1 = e1/esum
				local pvars ""
				local cpvars "cp1"
				forvalues j = 2/`K' {
					gen double p`j' = e`j'/esum
					local jm1 = `j' - 1
					gen double cp`j' = cp`jm1' + p`j'
					local pvars "`pvars' p`j'"
					local cpvars "`cpvars' cp`j'"
				}

				gen double u = runiform()
				gen byte T = 1
				forvalues j = 2/`K' {
					local jm1 = `j' - 1
					replace T = `j' if u > cp`jm1' & u <= cp`j'
				}

				drop `evars' `etavars' `pvars' `cpvars' esum u

				gen double mu_T = .
				forvalues j = 1/`K' {
					replace mu_T = `mu`j'' if T==`j'
				}
				gen double Y = mu_T + 1.5*x1 + 1.0*x1^2 + 1.5*x2 + 1.0*x1*x3 + 1.5*x3 + rnormal(0,1)
				drop mu_T

				local psvars ""
				forvalues j = 1/`K' {
					local psvars "`psvars' ps`j'"
				}

				capture mlogit T x1 x2 x3 c.x1#c.x3, base(1)
				local rc_correct = _rc
				if `rc_correct' == 0 {
					capture drop `psvars'
					capture predict double `psvars', pr
					local rc_correct = _rc
				}
				if `rc_correct' == 0 {
					gen double iptw_correct = .
					forvalues j = 1/`K' {
						replace iptw_correct = 1/ps`j' if T==`j'
					}
					drop `psvars'
				}

				capture mlogit T x1 x2 x3, base(1)
				local rc_misspec = _rc
				if `rc_misspec' == 0 {
					capture drop `psvars'
					capture predict double `psvars', pr
					local rc_misspec = _rc
				}
				if `rc_misspec' == 0 {
					gen double iptw_misspec = .
					forvalues j = 1/`K' {
						replace iptw_misspec = 1/ps`j' if T==`j'
					}
					drop `psvars'
				}

				qui summarize x1
				local xbar1 = r(mean)
				qui gen double x1sq = x1^2
				qui summarize x1sq
				local xbar1sq = r(mean)
				drop x1sq
				qui summarize x2
				local xbar2 = r(mean)
				qui gen double x1x3 = x1*x3
				qui summarize x1x3
				local xbar1x3 = r(mean)
				drop x1x3
				qui summarize x3
				local xbar3 = r(mean)
				local covoffset = 1.5*`xbar1' + 1.0*`xbar1sq' + 1.5*`xbar2' + 1.0*`xbar1x3' + 1.5*`xbar3'
				forvalues j = 1/`K' {
					local mutrue`j' = `mu`j'' + `covoffset'
				}

				local mabias0 = .
				local xabias0 = .
				local mabias1 = .
				local xabias1 = .
				local mabias2 = .
				local xabias2 = .

				capture regress Y i.T
				if _rc == 0 {
					capture qui margins T, post
					if _rc == 0 {
						matrix BB = r(table)
						local sumabs = 0
						local maxabs = 0
						forvalues j = 1/`K' {
							local av = abs(BB[1,`j'] - `mutrue`j'')
							local sumabs = `sumabs' + `av'
							if `av' > `maxabs' local maxabs = `av'
						}
						local mabias0 = `sumabs' / `K'
						local xabias0 = `maxabs'
					}
				}

				if `rc_correct' == 0 {
					capture regress Y i.T [pweight=iptw_correct]
					if _rc == 0 {
						capture qui margins T, post
						if _rc == 0 {
							matrix BB = r(table)
							local sumabs = 0
							local maxabs = 0
							forvalues j = 1/`K' {
								local av = abs(BB[1,`j'] - `mutrue`j'')
								local sumabs = `sumabs' + `av'
								if `av' > `maxabs' local maxabs = `av'
							}
							local mabias1 = `sumabs' / `K'
							local xabias1 = `maxabs'
						}
					}
				}

				if `rc_misspec' == 0 {
					capture regress Y i.T [pweight=iptw_misspec]
					if _rc == 0 {
						capture qui margins T, post
						if _rc == 0 {
							matrix BB = r(table)
							local sumabs = 0
							local maxabs = 0
							forvalues j = 1/`K' {
								local av = abs(BB[1,`j'] - `mutrue`j'')
								local sumabs = `sumabs' + `av'
								if `av' > `maxabs' local maxabs = `av'
							}
							local mabias2 = `sumabs' / `K'
							local xabias2 = `maxabs'
						}
					}
				}

				forvalues covnum = 1/3 {
					local covname x`covnum'

					capture regress `covname' i.T
					if _rc == 0 {
						capture esizeregk T, pwcompare
						if _rc == 0 {
							local fval = r(f)
							matrix PW = r(pairwise)
							local npr = rowsof(PW)
							local sumabs = 0
							local maxabs = 0
							forvalues rr = 1/`npr' {
								local av = abs(PW[`rr',1])
								local sumabs = `sumabs' + `av'
								if `av' > `maxabs' local maxabs = `av'
							}
							local meanabs = `sumabs' / `npr'
							post simres (`K') (`N') (`gam') (("`bal'"=="unequal")) (0) (`covnum') (`fval') (`meanabs') (`maxabs') (`mabias0') (`xabias0') (`repcount')
						}
						else {
							local ++failcount
						}
					}
					else {
						local ++failcount
					}

					if `rc_correct' == 0 {
						capture regress `covname' i.T [pweight=iptw_correct]
						if _rc == 0 {
							capture esizeregk T, pwcompare
							if _rc == 0 {
								local fval = r(f)
								matrix PW = r(pairwise)
								local npr = rowsof(PW)
								local sumabs = 0
								local maxabs = 0
								forvalues rr = 1/`npr' {
									local av = abs(PW[`rr',1])
									local sumabs = `sumabs' + `av'
									if `av' > `maxabs' local maxabs = `av'
								}
								local meanabs = `sumabs' / `npr'
								post simres (`K') (`N') (`gam') (("`bal'"=="unequal")) (1) (`covnum') (`fval') (`meanabs') (`maxabs') (`mabias1') (`xabias1') (`repcount')
							}
							else {
								local ++failcount
							}
						}
						else {
							local ++failcount
						}
					}

					if `rc_misspec' == 0 {
						capture regress `covname' i.T [pweight=iptw_misspec]
						if _rc == 0 {
							capture esizeregk T, pwcompare
							if _rc == 0 {
								local fval = r(f)
								matrix PW = r(pairwise)
								local npr = rowsof(PW)
								local sumabs = 0
								local maxabs = 0
								forvalues rr = 1/`npr' {
									local av = abs(PW[`rr',1])
									local sumabs = `sumabs' + `av'
									if `av' > `maxabs' local maxabs = `av'
								}
								local meanabs = `sumabs' / `npr'
								post simres (`K') (`N') (`gam') (("`bal'"=="unequal")) (2) (`covnum') (`fval') (`meanabs') (`maxabs') (`mabias2') (`xabias2') (`repcount')
							}
							else {
								local ++failcount
							}
						}
						else {
							local ++failcount
						}
					}

				}

			}

			local repfailed = (`failcount' > `failcount_before')
			_dots `rep' `repfailed'

		}
	}
}

postclose simres

di as txt _n "Done: k=4, n=2000. `repcount' replicates run, `failcount' failed sub-calls (regress/esizeregk errors, skipped)."
di as txt "Results saved to `outfile'"
